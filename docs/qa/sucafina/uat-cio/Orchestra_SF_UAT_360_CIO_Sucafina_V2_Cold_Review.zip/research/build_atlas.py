from pathlib import Path
from collections import Counter, defaultdict
import csv, json, re, unicodedata, html
import mistune

BASE=Path('/mnt/data/orchestra_sf_audit')
SHA='42d344a0efc4d85187388f149c54acac2db171da'
REPO=f'https://github.com/gustavomhss/Orchestra-SF'
PREFIX=f'{REPO}/blob/{SHA}/'

SURF=[r.split('|') for r in (BASE/'surfaces.psv').read_text(encoding='utf-8').strip().splitlines()]
ROUTES=[r.split('|') for r in (BASE/'routes.psv').read_text(encoding='utf-8').strip().splitlines()]
assert len(SURF)==70 and len(ROUTES)==165
assert len({r[1] for r in SURF})==70
assert len({tuple(r) for r in ROUTES})==165
assert {r[1] for r in SURF}=={r[0] for r in ROUTES}
assert all(any(r[0]==s[1] and r[2]==s[3] for r in ROUTES) for s in SURF)

LABELS={
'sf-dashboard':'Dashboard e prioridades','sf-people':'People e talentos',
'sf-portfolio':'Portfolio e cenários','sf-operations':'Operations e segurança',
'sf-procurement':'Procurement e fornecedores','sf-planner':'Planner e versões',
'sf-home':'Home e acesso','sf-work':'Meu trabalho e colaboração',
'sf-decisions':'Decisões governadas','sf-bi':'BI e visualização',
'sf-reviews':'Revisões e relatórios','sf-imports':'Imports e exports',
'sf-documents':'Documentos e evidências','sf-memory':'Memória e observações',
'sf-routines':'Rotinas e agentes'
}
ORDER=['sf-home','sf-dashboard','sf-people','sf-operations','sf-portfolio','sf-planner','sf-procurement','sf-work','sf-decisions','sf-bi','sf-reviews','sf-imports','sf-documents','sf-memory','sf-routines']
# Arquivos encontrados por inspeção de nomes/expectativas. Referência é índice de *teste-fonte*,
# jamais prova de execução/aceite. Uma suíte pode testar múltiplas surfaces.
TEST={
'CAP01':'u02','CAP02':'u38','CAP03':'u02,u39,u40','CAP04':'u39,u40','CAP05':'u39,u40',
'CAP06':'u03','CAP07':'u03','CAP08':'u47','CAP09':'u05','CAP10':'u05',
'CAP11':'u04','CAP12':'u29','CAP13':'u30','CAP14':'u15','CAP15':'u30','CAP16':'u31',
'CAP17':'u06','CAP18':'u07,u48','CAP19':'u07,u48','CAP20':'u08','CAP21':'u09',
'CAP22':'u45','CAP23':'u46','CAP25':'u12','CAP26':'u13','CAP27':'u14','CAP28':'u36',
'UI29':'u01','UI30':'u41','UI31':'u42','UI32':'u43','UI33':'u16',
'UI34':'u01,u16','UI35':'u17','UI36':'u17','UI37':'u17','UI38':'u17,u18',
'UI39':'u18','UI40':'u18','UI41':'u37','UI42':'u19','UI43':'u19','UI44':'u19',
'UI45':'u20,u21,u22','UI46':'u20,u21,u22',
'UI47':'u25','UI48':'u32','UI49':'u32','UI50':'u33',
'UI51':'u44','UI52':'u44','UI53':'u44','UI54':'u38',
'UI55':'u23','UI56':'u23','UI57':'u23','UI58':'u24','UI59':'u24','UI60':'u24',
'UI61':'u26','UI62':'u26,similarity217/ui62','UI63':'u26','UI64':'u27','UI65':'u27','UI66':'u34',
'UI67':'u01-host231,shell-guard237','UI68':'u23','UI69':'u28','UI70':'u35',
}
# CAP24 é verificado pelo catálogo e pelo produtor, mas nenhum uXX referente a CAP24 foi
# confirmado através dos títulos e referências examinados; usar ausência, não supor cobertura.
assert set(TEST)<=set(r[1] for r in SURF)

def test_url(t):
    path=(f'packages/app-shell/e2e/sucafina/native/journeys/{t}.spec.ts' if t.startswith('u') else
          f'packages/app-shell/e2e/sucafina/native/journeys/{t}.spec.ts')
    return f'{PREFIX}{path}'

with (BASE/'orchestra_sf_superficies_70.csv').open('w',newline='',encoding='utf-8-sig') as f:
    wr=csv.writer(f)
    wr.writerow(['chapter','surface_id','name','entry_route','primary_user_intent','route_variants','spec_test_refs','manifest_route_verified','e2e_executed_pass_on_candidate','evidence_note'])
    for chapter,id,name,route,intent in SURF:
        wr.writerow([chapter,id,name,route,intent,sum(r[0]==id for r in ROUTES),TEST.get(id,''),'YES','NOT_PROVEN','Arquivo de teste é evidência de fonte, não CI verde'])
with (BASE/'orchestra_sf_rotas_165.csv').open('w',newline='',encoding='utf-8-sig') as f:
    wr=csv.writer(f);wr.writerow(['surface_id','route_kind','route_pattern','same_candidate_source_sha'])
    for sid,kind,pattern in ROUTES:wr.writerow([sid,kind,pattern,SHA])

lines=['| Capítulo | ID | Superfície | Rota principal | Ação principal | Teste-fonte identificado |',
'|---|---|---|---|---|---|']
for chapter in ORDER:
    for _,id,name,route,intent in (x for x in SURF if x[0]==chapter):
        ts=TEST.get(id,'')
        tlinks=', '.join(f'[`{t}`]({test_url(t)})' for t in ts.split(',') if t) or 'Não indexado diretamente'
        lines.append(f'| {LABELS[chapter]} | `{id}` | {name.replace("|","/")} | `{route}` | {intent} | {tlinks} |')
    # IMPORTANT: do not insert blank rows inside a Markdown table. A prior
    # version separated chapters with an empty line, making 66 rows plain text
    # instead of searchable table rows in the HTML atlas.
surface_table='\n'.join(lines)
routes_table='\n'.join(['| ID | Variante | Caminho registrado |','|---|---|---|']+
                           [f'| `{a}` | `{b}` | `{c}` |' for a,b,c in ROUTES])
core=(BASE/'report_core.md').read_text(encoding='utf-8')
assert '{{SURFACE_TABLE}}' in core and '{{ROUTE_TABLE}}' in core
report=core.replace('{{SURFACE_TABLE}}',surface_table).replace('{{ROUTE_TABLE}}',routes_table)
report+='\n\n**Controle reprodutível:** `orchestra_sf_superficies_70.csv` e `orchestra_sf_rotas_165.csv` foram gerados do inventário lido no GitHub MCP; foram verificados localmente contagens, unicidade, ID e paridade das entradas.\n'
(BASE/'Orchestra_SF_Atlas_Completo.md').write_text(report,encoding='utf-8')

markdown=mistune.create_markdown(plugins=['table','strikethrough','task_lists','url'])
rendered=markdown(report)
used=set(); toc=[]

def slug(name):
    name=html.unescape(re.sub('<[^>]+>','',name))
    name=unicodedata.normalize('NFKD',name).encode('ascii','ignore').decode().lower()
    name=re.sub(r'[^a-z0-9]+','-',name).strip('-')[:65]
    if not name:name='secao'
    z=name;i=2
    while z in used:z=f'{name}-{i}';i+=1
    used.add(z)
    return z

def hd(m):
    level=int(m.group(1));title=m.group(2);id=slug(title)
    if level<=3: toc.append((level,id,re.sub('<[^>]+>','',title)))
    return f'<h{level} id="{id}">{title}</h{level}>'
rendered=re.sub(r'<h([1-4])>(.*?)</h\1>',hd,rendered,flags=re.S)
nav='\n'.join(f'<a href="#{id}" class="nav-l{level}">{html.escape(title)}</a>' for level,id,title in toc if level<=2)
# Searchable tables find by heading + nearest table, no web/CSS or third party JS.
js=r'''
(() => {
  const all = [...document.querySelectorAll('h2')];
  function nearTable(key){
    const h=all.find(el=>el.textContent.includes(key));if(!h)return;
    let table=h.nextElementSibling;
    while(table && table.tagName!=='TABLE' && table.tagName!=='H2') table=table.nextElementSibling;
    return table?.tagName==='TABLE'?table:null;
  }
  function instrument(key,id,hint){
    const t=nearTable(key);if(!t)return;
    t.id=id;t.classList.add('searchable');
    const wrap=document.createElement('div');wrap.className='searchbar';
    const input=document.createElement('input');input.type='search';input.placeholder=hint;input.setAttribute('aria-label',hint);
    const count=document.createElement('span');count.className='counter';
    const rows=[...t.querySelectorAll('tbody tr')];
    const sync=()=>{const q=input.value.toLocaleLowerCase('pt-BR');let seen=0;
      for(const r of rows){const ok=r.textContent.toLocaleLowerCase('pt-BR').includes(q);r.hidden=!ok;if(ok)seen++;}
      count.textContent=seen+' / '+rows.length;
    };input.addEventListener('input',sync);wrap.append(input,count);t.before(wrap);sync();
  }
  instrument('Catálogo das 70 superfícies','surfaceTable','Buscar por módulo, CAP/UI, rota ou funcionalidade…');
  instrument('Apêndice A','routeTable','Buscar entre as 165 rotas…');
})();
'''
styles=r'''
:root{color-scheme:dark;--bg:#070c16;--paper:#101a2c;--ink:#f1f5ff;--muted:#a6b5d0;--edge:#2b3d59;--accent:#73adff;--high:#91baff;}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--ink);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;line-height:1.66;font-size:15px}
.side{position:fixed;inset:0 auto 0 0;width:272px;padding:20px 16px;background:#0b1220;border-right:1px solid var(--edge);overflow:auto}
.brand{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--accent);margin:4px 10px 6px;font-weight:800}.subbrand{font-size:11px;color:var(--muted);padding:0 10px 15px;line-height:1.55}
nav a{display:block;color:var(--muted);font-size:12px;padding:7px 10px;border-radius:6px;text-decoration:none;margin-bottom:2px}nav a:hover,nav a:focus-visible{color:var(--ink);background:#22324c}
main{margin-left:272px;max-width:1510px;padding:50px 5vw 110px}
article{max-width:1110px}h1{font-size:36px;line-height:1.12;letter-spacing:-.03em;margin:0 0 23px;color:#fff}
h2{font-size:24px;line-height:1.25;letter-spacing:-.015em;margin:52px 0 14px;border-top:1px solid var(--edge);padding-top:32px;scroll-margin-top:16px}
h3{font-size:18px;margin:30px 0 11px;color:#bad5ff;scroll-margin-top:20px}h4{font-size:15px;color:#b3d2ff}
a{color:var(--accent);text-decoration:underline;text-underline-offset:2px}a:hover{color:#cfe3ff}
p,li{color:#d6e0f2;overflow-wrap:anywhere}strong{color:#fff}blockquote{border-left:3px solid #6494e3;padding:12px 17px;margin:20px 0;background:#142037;border-radius:0 9px 9px 0;color:#d6e0ff}
blockquote p{margin:0}code{font-family:'SFMono-Regular',Consolas,'Liberation Mono',monospace;font-size:.88em;color:#a8d4ff;background:#16243a;padding:2px 4px;border-radius:4px}pre{overflow:auto;padding:17px 19px;background:#070d17;border:1px solid var(--edge);border-radius:9px}pre code{background:none;white-space:pre;font-size:12px;overflow-wrap:normal;word-break:normal}
table{border-collapse:separate;border-spacing:0;width:100%;font-size:12.5px;display:block;overflow-x:auto;margin:16px 0 25px;max-height:unset}
th,td{padding:10px 12px;border-bottom:1px solid #263850;vertical-align:top;text-align:left}th{position:sticky;top:0;background:#16243b;color:#d7e7ff;white-space:nowrap;font-size:12px}td{background:#0d1726;color:#d2dff2}tr:hover td{background:#15223a}tr[hidden]{display:none}
.searchbar{margin-top:20px;display:flex;gap:12px;align-items:center}.searchbar input{background:#111e31;border:1px solid #43628b;border-radius:9px;color:#fff;outline:none;padding:12px 14px;min-width:min(100%,420px);font:inherit}.searchbar input:focus{border-color:#79b6ff;box-shadow:0 0 0 3px #294e7a}.counter{font-size:12px;color:#b5c7e7;white-space:nowrap}
.topnote{display:flex;gap:10px;flex-wrap:wrap;margin:22px 0 10px}.topnote span{border:1px solid #2d4a79;color:#b9d5ff;background:#11223b;border-radius:15px;padding:5px 12px;font-size:12px}
@media(max-width:1000px){.side{position:static;width:auto;height:auto;padding:15px 20px;border-right:none;border-bottom:1px solid var(--edge)}.side nav{display:none}main{margin:0;padding:32px 19px 85px}article{max-width:100%}h1{font-size:28px}h2{font-size:22px}.searchbar{flex-wrap:wrap}.searchbar input{width:100%}}
@media print{.side{display:none}main{margin:0;padding:0}body{background:#fff;color:#111;--muted:#444;--ink:#111;--edge:#ccc;--accent:#004fa2}h1,h2,h3,strong{color:#111}p,li,td{color:#111}td,th{background:#fff;color:#111}table{font-size:10px}.searchbar{display:none}}
'''
html_doc=f'''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Orchestra-SF · Atlas funcional completo</title><style>{styles}</style></head><body><aside class="side"><div class="brand">HU GR · ORCHESTRA SF</div><div class="subbrand">Mapa de jornadas · governança · implementação · CI<br>Pin: {SHA[:12]}…</div><nav aria-label="Sumário">{nav}</nav></aside><main><div class="topnote"><span>70 superfícies</span><span>165 rotas</span><span>15 capítulos</span><span>306 operações registradas</span><span>Homologação: não comprovada</span></div><article>{rendered}</article></main><script>{js}</script></body></html>'''
(BASE/'Orchestra_SF_Atlas_Interativo.html').write_text(html_doc,encoding='utf-8')

print('Built files:')
for p in sorted(BASE.iterdir()):
 if p.name.endswith(('.csv','.html','.md')) and p.name!='report_core.md':print(p,p.stat().st_size)
print('Tests indexed',len(TEST),'not indexed',set(r[1] for r in SURF)-set(TEST))
