# Como reproduzir a verificação do atlas

- **Fonte congelada:** `42d344a0efc4d85187388f149c54acac2db171da`. A base foi observada em `88e37c1f82823d8482051ef279cff433b6f18691`, com dois commits adicionais somando 14 arquivos de CI/release e testes de transporte, sem alteração da fonte funcional mapeada.
- **CI diagnóstico:** [run 43995388263](https://github.com/gustavomhss/Orchestra-SF/actions/runs/43995388263), SHA `aec42536013f06d518e0cf5053982e319a41199a`, `5/12` jobs verdes, não promovível.
- **GitHub/API:** esta cópia não contém os 24 mil arquivos do repositório, tampouco credenciais, dados reais ou logs completos. As observações remotas estão resumidas em `Orchestra_SF_Proveniencia_Triple_Check.json` e podem ser repetidas no MCP GitHub contra esses SHAs.
- **Auditoria local sem rede:** rode `python qa_validate.py` em ambiente com `beautifulsoup4` disponível. Ela confere 35 invariantes dos dados, CSVs, HTML e Markdown entregues.
- **Auditoria de HTML com navegador:** rode `python browser_qa.py` em ambiente com Playwright Python e Chromium. Ela carrega o documento HTML em memória e confere 12 comportamentos, incluindo filtro e mobile.
- **Recriar atlas:** `python build_atlas.py` recompõe HTML, Markdown e dois CSVs a partir de `report_core.md`, `surfaces.psv` e `routes.psv`. O mapa novo `Orchestra_SF_Matriz_Triple_Check_70.csv` e os seis digests vêm de `build_qa_matrix.py`.
- **Atenção:** scripts de validação dos artefatos não executam Orchestra, Azure, CI ou autenticadores. Para atestar J01–J08, é necessário CI verde no SHA exato, segredos e atores reais e comprovação de leitura/aplicação/recibo, sem fallback sintético.
