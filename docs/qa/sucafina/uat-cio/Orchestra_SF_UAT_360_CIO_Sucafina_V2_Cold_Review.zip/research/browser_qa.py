#!/usr/bin/env python3
"""Live headless Chromium QA for the standalone, offline HTML atlas.
This does not exercise the Orchestra application or its protected business APIs.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
BASE=Path(__file__).resolve().parent
url=(BASE/'Orchestra_SF_Atlas_Interativo.html').resolve().as_uri()
results=[]
def check(name,passed,detail=''):
 results.append({'test':name,'status':'PASS' if passed else 'FAIL','detail':detail})
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1440,'height':900})
 errors=[]
 page.on('pageerror', lambda e: errors.append(str(e)))
 page.set_content((BASE/'Orchestra_SF_Atlas_Interativo.html').read_text(encoding='utf-8'), wait_until='load')
 surface=page.locator('#surfaceTable tbody tr')
 routes=page.locator('#routeTable tbody tr')
 check('H1 table initialization and 70 DOM rows',surface.count()==70, f'count={surface.count()}')
 check('H2 165 DOM route rows',routes.count()==165, f'count={routes.count()}')
 check('H3 no JavaScript runtime error',len(errors)==0, repr(errors))
 check('H4 initial counter shows 70/70',page.locator('.searchbar .counter').first.inner_text()=='70 / 70')
 inp=page.locator('input[placeholder*="Buscar por módulo"]')
 inp.fill('CAP24')
 visible=surface.filter(visible=True)
 check('H5 search filter CAP24 finds exactly 1',visible.count()==1, f'visible={visible.count()}')
 check('H6 CAP24 row really displays Procurement Dashboard', 'Procurement' in visible.first.inner_text())
 inp.fill('')
 check('H7 search reset restores 70 rows',surface.filter(visible=True).count()==70)
 routing=page.locator('input[placeholder*="Buscar entre as 165"]')
 routing.fill('/sf-procurement/requests')
 rr=routes.filter(visible=True).count()
 check('H8 route filter works',0<rr<165,f'found={rr}')
 routing.fill('')
 check('H9 route reset restores 165 rows',routes.filter(visible=True).count()==165)
 for width in (320,768,1440):
  page.set_viewport_size({'width':width,'height':900})
  overflow=page.evaluate('document.documentElement.scrollWidth-document.documentElement.clientWidth')
  check(f'H10 responsive no document horizontal scroll @ {width}px',overflow<=1,f'overflow_px={overflow}')
 page.set_viewport_size({'width':1440,'height':900})
 page.evaluate('window.scrollTo(0,0)')
 page.screenshot(path=str(BASE/'Orchestra_SF_Atlas_Validacao_Visual.png'),full_page=False)
 browser.close()
result={'name':'orchestra-sf-html-chromium-audit','sourceSHA':'42d344a0efc4d85187388f149c54acac2db171da','scope':'offline HTML atlas ONLY, not product E2E','passCount':sum(x['status']=='PASS' for x in results),'failCount':sum(x['status']=='FAIL' for x in results),'checks':results}
(BASE/'Orchestra_SF_Validacao_Navegador.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for r in results:print(r['status'],r['test'],r['detail'])
print('RESULT',result['passCount'],'/',len(results))
raise SystemExit(0 if result['failCount']==0 else 1)
