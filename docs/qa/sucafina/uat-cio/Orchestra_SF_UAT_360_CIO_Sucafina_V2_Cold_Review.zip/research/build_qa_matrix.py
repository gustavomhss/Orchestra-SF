from pathlib import Path
import csv, hashlib, json, datetime
BASE=Path('/mnt/data/orchestra_sf_audit')
SHA='42d344a0efc4d85187388f149c54acac2db171da'
REPO='https://github.com/gustavomhss/Orchestra-SF'
SIX={
 'dashboard-budget.ts': {'old':'b64f2f49b42aea2f2d74d6c1da18a3bce4873365', 'current':'21e1a63b3a88db673c79170cdf873be0c9949a27','ids':'CAP01 CAP03 CAP04 CAP05'},
 'dashboard-people.ts': {'old':'de499e6d34af826add34bee4125bcfba4e57ddb8','current':'c8be36e9eb49f6fbd10fae3429d6f3cd2af0151e','ids':'CAP02 CAP06 CAP07 CAP08'},
 'dashboard-portfolio.ts': {'old':'20a6cec3713f95e4dfac262ce7e741f72c857231','current':'3b4e54da44683e56687cc744cd7c42ba7da4d8a4','ids':'CAP09 CAP10 CAP13 CAP14 CAP15 CAP16'},
 'dashboard-operations.ts': {'old':'a00c93ac141489e7cfca1895591f1496c7fabf45','current':'e9080c80975246722a5f9e11084bc44f5d677f6e','ids':'CAP11 CAP12'},
 'planner.ts': {'old':'17c65e08c833dfd1fcad582ef4eaac78a1c5ea4b','current':'8e0d45b2d29815fe87c0351bc24275cbc53e49e9','ids':'CAP17 CAP18 CAP19 CAP20 CAP21 CAP22 CAP23'},
 'procurement.ts': {'old':'20a3ec5a30ac0fce6b35f05750d1b3dced11c45b','current':'fd7e9dc0e3f3791fe4e09979e4e5e3223992c8d5','ids':'CAP24 CAP25 CAP26 CAP27 CAP28'},
}
assert sum(len(v['ids'].split()) for v in SIX.values())==28
producer_for={id:name for name,v in SIX.items() for id in v['ids'].split()}
with (BASE/'orchestra_sf_superficies_70.csv').open(encoding='utf-8-sig',newline='') as f:
 s=list(csv.DictReader(f))
with (BASE/'orchestra_sf_rotas_165.csv').open(encoding='utf-8-sig',newline='') as f:
 r=list(csv.DictReader(f))
headers=['surface_id','chapter','surface_name','entry_route','primary_user_intent','variants','contract_catalog_binding','host_route_binding','original_producer_source','producer_sha_comparison','native_journey_source_refs','native_specific_e2e_evidence','known_functional_exception','integrated_e2e_on_this_SHA','release_go_live_evidence','manifest_url','route_registry_url','technical_reading']
notes={
'CAP24': 'No u10/u11 dedicated native spec in candidate; generic navigation and source producer exist',
'UI32':'V2 native views explicitly shown unavailable; legacy personal views must be distinguished',
'UI62':'Additional source-backed similarity217/ui62 Playwright spec; extra operation outside 305 catalog IDs',
'UI66':'Schedule editor blocked without original producer scheduleDetails.read; status started is not completed',
'UI31':'Catalog GET vs installed POST by privacy policy; transport test exists; update baseline spec',
'UI67':'No Microsoft real tenant verification from synthetic code tests; identity context only',
}
with (BASE/'Orchestra_SF_Matriz_Triple_Check_70.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=headers);w.writeheader()
 for x in s:
  id=x['surface_id'];name=producer_for.get(id)
  status='HISTORICAL_BLOB_DIFFERS_CURRENT_CANDIDATE' if name else 'LOGICAL_BINDING_NOT_A_SINGLE_PINNED_PRODUCER_BLOB'
  o=notes.get(id,'')
  if name and id!='CAP24':o=(o+'; ' if o else '')+'6/6 original producer files changed blob vs historical pin, semantic equivalence not proven'
  spec=x['spec_test_refs'];
  w.writerow({'surface_id':id,'chapter':x['chapter'],'surface_name':x['name'],'entry_route':x['entry_route'],
  'primary_user_intent':x['primary_user_intent'],'variants':x['route_variants'],'contract_catalog_binding':'RESOURCE_RESOLVES; OPS_PRESENT','host_route_binding':'ROUTE_AND_HOST_SOURCE_REFERENCED',
  'original_producer_source':f'modules/sucafina/Sucafinav1/runtime/{name}' if name else '',
  'producer_sha_comparison':status,'native_journey_source_refs':spec,
  'native_specific_e2e_evidence':'MISSING_DEDICATED_UXX' if id=='CAP24' else 'SOURCE_ONLY_NOT_INSTALLED_RESULT',
  'known_functional_exception':o,'integrated_e2e_on_this_SHA':'NOT_PROVEN',
  'release_go_live_evidence':'NOT_PROVEN','manifest_url':f'{REPO}/blob/{SHA}/modules/sucafina/Sucafinav1/docs/sf2h/native-ui/execution/surface-manifest.json',
  'route_registry_url':f'{REPO}/blob/{SHA}/packages/app-shell/src/orchestra/chapters/sucafina/route-registry.ts',
  'technical_reading':'D/I/T sources inspected; E demands full installed run for same candidate, actor, data and version'})
with (BASE/'Orchestra_SF_Producers_Digest_Drift.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['file','historical_blob','current_candidate_blob','affected_surfaces','historical_revision','candidate_revision','interpretation'])
 for name,v in SIX.items():
  w.writerow([f'modules/sucafina/Sucafinav1/runtime/{name}',v['old'],v['current'],v['ids'], 'b10c424a6b318879fc30f11d03ba1cfeffda7d1a',SHA,'byte drift confirmed; no removal of existing exports seen; semantic contract must be requalified'])
print('Matrix 70, six producer drift files done')
