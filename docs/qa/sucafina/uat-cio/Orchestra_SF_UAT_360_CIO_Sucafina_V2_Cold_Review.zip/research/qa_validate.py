#!/usr/bin/env python3
"""Orchestra-SF atlas artifact QA, deterministic and offline.

This validator intentionally does NOT call GitHub/Actions or claim product E2E
success. It verifies consistency of the exported, already source-inspected data.
"""
from __future__ import annotations
from pathlib import Path
from bs4 import BeautifulSoup
from collections import Counter, defaultdict
import csv, json, re, hashlib, sys, zipfile

BASE=Path(__file__).resolve().parent
SHA='42d344a0efc4d85187388f149c54acac2db171da'
checks=[]
def check(name, condition, detail=''):
    checks.append({'check': name, 'status': 'PASS' if condition else 'FAIL', 'detail': detail})

def rows(name):
    with (BASE/name).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

surfaces=rows('orchestra_sf_superficies_70.csv')
routes=rows('orchestra_sf_rotas_165.csv')
qmatrix=rows('Orchestra_SF_Matriz_Triple_Check_70.csv')
drift=rows('Orchestra_SF_Producers_Digest_Drift.csv')
check('A1 surfaces=70',len(surfaces)==70, f'actual={len(surfaces)}')
check('A2 28 CAP + 42 UI', sum(x['surface_id'].startswith('CAP') for x in surfaces)==28 and sum(x['surface_id'].startswith('UI') for x in surfaces)==42)
check('A3 15 distinct chapters',len(set(x['chapter'] for x in surfaces))==15)
check('A4 IDs unique',len({x['surface_id'] for x in surfaces})==70)
check('A5 routes=165',len(routes)==165)
check('A6 route ID set equals 70 surface IDs',set(x['surface_id'] for x in surfaces)==set(x['surface_id'] for x in routes))
check('A7 distinct route patterns',len({x['route_pattern'] for x in routes})==165)
check('A8 distinct (ID, kind, path)',len({(x['surface_id'],x['route_kind'],x['route_pattern']) for x in routes})==165)
check('A9 every primary entry present',all((x['surface_id'],x['entry_route']) in {(r['surface_id'],r['route_pattern']) for r in routes} for x in surfaces))
counts=Counter(x['surface_id'] for x in routes)
check('A10 variants counts by ID align',all(int(x['route_variants'])==counts[x['surface_id']] for x in surfaces))
check('A11 all exported routes on frozen SHA', all(x['same_candidate_source_sha']==SHA for x in routes))
check('A12 original source PSL surface parity', sorted([tuple(x.split('|')) for x in (BASE/'surfaces.psv').read_text().strip().splitlines()]) == sorted([(x['chapter'], x['surface_id'], x['name'], x['entry_route'], x['primary_user_intent']) for x in surfaces]))
check('A13 original source PSL route parity', sorted([tuple(x.split('|')) for x in (BASE/'routes.psv').read_text().strip().splitlines()]) == sorted([(x['surface_id'],x['route_kind'],x['route_pattern']) for x in routes]))
check('A14 matrix covers same exact 70 IDs',len(qmatrix)==70 and set(x['surface_id'] for x in qmatrix)==set(x['surface_id'] for x in surfaces))
check('A15 matrix never claims green E2E', all(x['integrated_e2e_on_this_SHA']=='NOT_PROVEN' and x['release_go_live_evidence']=='NOT_PROVEN' for x in qmatrix))
check('A16 explicit CAP24 E2E coverage gap',[(x['surface_id'],x['native_specific_e2e_evidence']) for x in qmatrix if x['native_specific_e2e_evidence']=='MISSING_DEDICATED_UXX']==[('CAP24','MISSING_DEDICATED_UXX')])
check('A17 28 CAP source drift flags', sum(x['producer_sha_comparison']=='HISTORICAL_BLOB_DIFFERS_CURRENT_CANDIDATE' for x in qmatrix)==28)
check('A18 six source digests mapped to 28 unique CAPs',len(drift)==6 and sum(len(x['affected_surfaces'].split()) for x in drift)==28 and all(len(x['historical_blob'])==40 and len(x['current_candidate_blob'])==40 and x['historical_blob']!=x['current_candidate_blob'] for x in drift))
check('A19 exactly 1 absent dedicated uXX test row', [x['surface_id'] for x in surfaces if not x['spec_test_refs']]==['CAP24'])
check('A20 UI62 specialized spec indexed', 'similarity217/ui62' in next(x['spec_test_refs'] for x in surfaces if x['surface_id']=='UI62'))

html_text=(BASE/'Orchestra_SF_Atlas_Interativo.html').read_text(encoding='utf-8')
soup=BeautifulSoup(html_text,'html.parser')
tables=soup.find_all('table')
def by_header(fragment):
 return [table for table in tables if any(fragment in th.get_text(' ',strip=True) for th in table.select('th'))]
st=by_header('Superfície');rt=by_header('Caminho registrado')
check('B1 exactly one HTML surfaces table',len(st)==1)
check('B2 HTML truly renders 70 searchable surface rows',len(st[0].select('tbody tr'))==70 if st else False)
check('B3 HTML truly renders 165 route rows',len(rt)==1 and len(rt[0].select('tbody tr'))==165)
if st:
 rendered_ids=[r.find_all('td')[1].get_text(' ',strip=True) for r in st[0].select('tbody tr')]
 check('B4 HTML surface ID multiset equals CSV',Counter(rendered_ids)==Counter(x['surface_id'] for x in surfaces))
if rt:
 htmlroutes=[(r.find_all('td')[0].get_text(' ',strip=True),r.find_all('td')[1].get_text(' ',strip=True),r.find_all('td')[2].get_text(' ',strip=True)) for r in rt[0].select('tbody tr')]
 check('B5 HTML routes match CSV tuple set',set(htmlroutes)=={(x['surface_id'],x['route_kind'],x['route_pattern']) for x in routes})
nav=[a.get('href','') for a in soup.select('nav a') if a.get('href','').startswith('#')]
ids={x.get('id') for x in soup.select('[id]')}
check('B6 no dead internal nav anchors', bool(nav) and all(a[1:] in ids for a in nav))
check('B7 client-side search searches table tbody',"querySelectorAll('tbody tr')" in html_text and "instrument('Catálogo das 70 superfícies'" in html_text)
check('B8 no split-table plaintext surface rows',not any(re.match(r'^\|\s*(Dashboard|People|Operations|Portfolio|Planner|Procurement|BI|Revisões)',p.get_text(' ',strip=True)) for p in soup.find_all('p')))
check('B9 offline HTML includes no remote CSS/JS',not any(str(x.get('src','')).startswith('http') for x in soup.find_all('script')) and not any(str(x.get('href','')).startswith('http') for x in soup.find_all('link')))

md=(BASE/'Orchestra_SF_Atlas_Completo.md').read_text(encoding='utf-8')
check('C1 report expands all placeholders','{{SURFACE_TABLE}}' not in md and '{{ROUTE_TABLE}}' not in md)
check('C2 canonical J01-J08 headings count=8',len(re.findall(r'^### J0[1-8]\b',md,flags=re.M))==8)
check('C3 correction addendum QA-01..QA-08 present',all(f'QA-0{i}' in md for i in range(1,9)))
check('C4 source SHA pinned in report',SHA in md)
check('C5 report explains no production E2E release proof','homologação operacional completa NÃO comprovada' in md)
check('C6 no proven status for 70 E2E',not any(x['integrated_e2e_on_this_SHA']=='PASS' for x in qmatrix))

failed=[x for x in checks if x['status']!='PASS']
result={'schema':'orchestra-sf-atlas-artifact-qa-v2','sourceSHA':SHA,
'purpose':'self-consistency of exported artifacts only; NOT production/UAT proof',
'passCount':len(checks)-len(failed),'failCount':len(failed),'checks':checks}
(BASE/'Orchestra_SF_Validacao_Artefatos.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for x in checks: print(f"{'PASS' if x['status']=='PASS' else 'FAIL'} {x['check']} {x['detail']}")
print(f"RESULT {len(checks)-len(failed)}/{len(checks)} artifact checks passed")
sys.exit(0 if not failed else 1)
